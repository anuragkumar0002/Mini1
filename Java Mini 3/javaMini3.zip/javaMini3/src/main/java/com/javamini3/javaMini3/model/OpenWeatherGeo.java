package com.javamini3.javaMini3.model;

import lombok.Data;

@Data
public class OpenWeatherGeo {

        private double lat;
        private double lon;
    }

